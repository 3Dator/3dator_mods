# 3dator_firmware
In this repository you find all the files for the 3Dator mods

http://3dator.com

http://wiki.3dator.com

# what to do with the files
* Feel free to print the files for your 3Dator or even some other fdm machine.
* Modify the files to fit your needs, keep in mind to share what you've done with others and don't forget to mention us ;)
* You just stumbled across this and only want to buy a full kit? Visit our shop: http://3dator.com/shop
